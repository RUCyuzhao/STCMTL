#' Isolet
#'
#' This dataset was collected from 150 persons who spoke the name of each letter in the English alphabet twice.
#'
#' @format A large list with train data, test data and group.
"isolet"
