#' School
#'
#' This dataset is from Inner London Education Authority, which records the examination scores of 15,362 students from 139 secondary schools in London during 1985-1987.
#'
#' @format A large list with train data, test data and group.
"school"
