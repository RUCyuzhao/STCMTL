#' Mnist
#'
#' This multi-class classification dataset is from 10 handwritten digits and we extract a part of the dataset to form a multi-task problem.
#'
#' @format A large list with train data, test data and group.
"Mnist"
